@extends('backoffice.template.template')

@section('back')
    
<h1> Bienvenue dans le dashboard</h1>   
@endsection

