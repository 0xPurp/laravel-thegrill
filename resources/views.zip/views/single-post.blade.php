<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <!--[if IE]><meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'><![endif]-->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="shortcut icon" href="assets/img/ico/favicon.ico">
    <link rel="apple-touch-icon" sizes="144x144" href="assets/img/ico/apple-touch-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="114x114" href="assets/img/ico/apple-touch-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="72x72" href="assets/img/ico/apple-touch-icon-72x72.png">
    <link rel="apple-touch-icon" href="assets/img/ico/apple-touch-icon-57x57.png">

    <title>Piper by Distinctive Themes</title>

    <!-- Bootstrap Core CSS -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/animate.css" rel="stylesheet">
    <link href="assets/css/plugins.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="assets/css/style.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="assets/font-awesome-4.1.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="assets/css/pe-icons.css" rel="stylesheet">

</head>

<body id="page-top" class="animated-navigation">


    <div class="master-wrapper">

        <div class="preloader">
            <div class="preloader-img">
                <span class="loading-animation animate-flicker"><img src="assets/img/loading.GIF" alt="loading" /></span>
            </div>
        </div>

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-fixed-top fadeInDown" data-wow-delay="0.2s">
            <div class="container-fluid">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header page-scroll">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#main-navigation">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand smoothie" href="index.html">P<span class="theme-accent-color">I</span>PER</a>
                </div>
                <div id="navbar-social">
                    <ul class="smoothie list-inline social-links">
                        <li>
                            <a href="#"><i class="fa fa-twitter"></i></a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-pinterest"></i></a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-dribbble"></i></a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-facebook"></i></a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-behance"></i></a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-linkedin"></i></a>
                        </li>
                    </ul>
                </div>

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="main-navigation">
                    <ul class="nav navbar-nav navbar-right">
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-hover="dropdown" data-toggle="dropdown">Home <span class="pe-7s-angle-down"></span></a>
                            <ul class="dropdown-menu" role="menu">
                                <li><a href="index.html">Fullscreen Slider</a></li>
                                <li><a href="index-video.html">Fullscreen Video</a></li>                                
                                <li><a href="index-single-page.html">Single Page</a></li>                            
                                <li><a href="index-landing-page.html">Landing Page</a></li>
                                <li><a href="index-minimal.html">Minimal</a></li>
                                <li><a href="index-countdown.html">Coming Soon</a></li>
                            </ul>
                        </li>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-hover="dropdown" data-toggle="dropdown">Portfolio <span class="pe-7s-angle-down"></span></a>
                            <ul class="dropdown-menu" role="menu">
                                <li><a href="portfolio-grid.html">Portfolio Grid</a></li>
                                <li><a href="portfolio-masonry.html">Portfolio Masonry</a></li>
                                <li><a href="single-portfolio.html">Project Slider</a></li>
                                <li><a href="single-portfolio-carousel.html">Project Carousel</a></li>
                                <li><a href="single-portfolio-video.html">Project Video</a></li>
                                <li><a href="single-portfolio-fullscreen.html">Project Fullscreen</a></li>
                                <li><a href="single-portfolio-fullscreen-video.html">Project Fullscreen Video</a></li>
                                <li><a href="single-portfolio-image-list.html">Project Image List</a></li>
                            </ul>
                        </li>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-hover="dropdown" data-toggle="dropdown">Blog <span class="pe-7s-angle-down"></span></a>
                            <ul class="dropdown-menu" role="menu">
                                <li><a href="blog.html">Blog Archive</a></li>
                                <li><a href="single-post.html">Single Post</a></li>
                            </ul>
                        </li>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-hover="dropdown" data-toggle="dropdown">Extras <span class="pe-7s-angle-down"></span></a>
                            <ul class="dropdown-menu" role="menu">
                                <li><a href="404.html">404</a></li>
                            </ul>
                        </li>
                        <li><a href="#search"><i class="pe-7s-search"></i></a></li>
                        <li id="menu-trigger-wrapper">
                            <div class="pull-right">
                                <button type="button" id="menu-toggle" class="tcon tcon-menu--xcross" aria-label="toggle menu">
                                  <span class="tcon-menu__lines" aria-hidden="true"></span>
                                  <span class="tcon-visuallyhidden">toggle menu</span>
                                </button>
                            </div>  
                        </li>
                    </ul>

                </div>
                <!-- /.navbar-collapse -->         

            </div>
            <!-- /.container-fluid -->
        </nav>

        <div id="search-wrapper">
            <button type="button" class="close">×</button>
            <form>
                <input type="search" value="" placeholder="Enter Search Term" />
                <button type="submit" class="btn btn-primary">Search</button>
            </form>
        </div>

        <section class="dark-wrapper opaqued parallax" data-parallax="scroll" data-image-src="assets/img/bg/bg2.jpg" data-speed="0.8">
            <div class="section-inner">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12 mt30 text-center wow fadeIn" data-wow-delay="0.2s">
                            <div id="bannertext">
                                <h2 class="section-heading">Single <span class="theme-accent-color">Blog Post</span></h2>
                                <div class="item-metas text-muted mb30 white">
                                    <span class="meta-item"><i class="pe-icon pe-7s-folder"></i> POSTED IN <span class="secondary-font">News</span></span>
                                    <span class="meta-item"><i class="pe-icon pe-7s-ticket"></i> TAGS <span class="secondary-font">Photography</span></span>
                                    <span class="meta-item"><i class="pe-icon pe-7s-user"></i> AUTHOR <span class="secondary-font">Danny Jones</span></span>
                                    <span class="meta-item"><i class="pe-icon pe-7s-comment"></i> COMMENTS <span class="secondary-font">3</span></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section>
            <div class="section-inner">
                <div class="container">
                    <div class="row">
                        <div id="post-content" class="col-sm-12 blog-item mb60 wow fadeIn" data-wow-delay="0.2s">
                            <div class="row">
                                <div class="col-xs-2 post-left-col">
                                    <div class="post-date heading-font">
                                        <span class="the-date">19</span>
                                        <span class="the-month">April, 2014</span>
                                    </div>
                                </div>
                                <div class="col-xs-10 post-center single-post-content">
                                    <div class="mb50">
                                        <p>Behind sooner dining so window excuse he summer. Breakfast met certainty and fulfilled propriety led. Waited get either are wooded little her. Contrasted unreserved as mr particular collecting it everything as indulgence. Seems ask meant merry could put. Age old begin had boy noisy table front whole given. Behind sooner dining so window excuse he summer. Breakfast met certainty and fulfilled propriety led. Waited get either are wooded little her. Contrasted unreserved as mr particular collecting it everything as indulgence. Seems ask meant merry could put. Age old begin had boy noisy table front whole given.</p>
                                        <p>Behind sooner dining so window excuse he summer. Breakfast met certainty and fulfilled propriety led. Waited get either are wooded little her. Contrasted unreserved as mr particular collecting it everything as indulgence. Seems ask meant merry could put. Age old begin had boy noisy table front whole given.</p>
                                    </div>

                                    <div id="comments-list" class="wow fadeIn" data-wow-delay="0.2s">
                                        <div class="mt60 mb50 single-section-title">
                                            <h3>3 Comments</h3>
                                        </div>
                                        <div class="media">
                                            <div class="pull-left">
                                                <img class="avatar comment-avatar" src="http://lorempixel.com/g/80/80/people/9" alt="">
                                            </div>
                                            <div class="media-body">
                                                <div class="well">
                                                    <div class="media-heading">
                                                        <span class="heading-font">Dave Evans</span>&nbsp; <small>30th Jan, 2015</small>
                                                    </div>
                                                    <p>Was are delightful solicitude discovered collecting man day. Resolving neglected sir tolerably but existence conveying for. Day his put off unaffected literature partiality inhabiting.</p>
                                                    <a class="btn btn-primary pull-right mt30" href="#">Reply</a>
                                                </div>
                                                <div class="media">
                                                    <div class="pull-left">
                                                        <img class="avatar comment-avatar" src="http://lorempixel.com/g/80/80/people/5" alt="">
                                                    </div>
                                                    <div class="media-body">
                                                        <div class="well">
                                                            <div class="media-heading">
                                                                <span class="heading-font">Dave Evans</span>&nbsp; <small>30th Jan, 2015</small>
                                                            </div>
                                                            <p>Wicket longer admire do barton vanity itself do in it. Preferred to sportsmen it engrossed listening. Park gate sell they west hard for the. Abode stuff noisy manor blush yet the far. Up colonel so between removed so do.</p>
                                                            <a class="btn btn-primary pull-right mt30" href="#">Reply</a>
                                                        </div>
                                                    </div>
                                                </div><!--/.media-->
                                            </div>
                                        </div><!--/.media-->
                                        <div class="media">
                                            <div class="pull-left">
                                                <img class="avatar comment-avatar" src="http://lorempixel.com/g/80/80/people/6" alt="">
                                            </div>
                                            <div class="media-body">
                                                <div class="well">
                                                    <div class="media-heading">
                                                        <span class="heading-font">Dave Evans</span>&nbsp; <small>30th Jan, 2015</small>
                                                    </div>
                                                    <p>Quitting informed concerns can men now. Projection to or up conviction uncommonly delightful continuing. In appetite ecstatic opinions hastened by handsome admitted.</p>
                                                    <a class="btn btn-primary pull-right mt30" href="#">Reply</a>
                                                </div>
                                            </div>
                                        </div><!--/.media-->

                                        <div id="comments-form" class="row wow fadeIn" data-wow-delay="0.2s">
                                            <div class="col-md-12">
                                                <div class="mt60 mb50 single-section-title">
                                                    <h3>Leave A Reply</h3>
                                                </div>
                                                <div id="message"></div>
                                                <form method="post" id="commentform" class="comment-form">
                                                    <input type="text" class="form-control col-md-4" name="name" placeholder="Your Name *" id="name" required data-validation-required-message="Please enter your name." />
                                                    <input type="text" class="form-control col-md-4" name="email" placeholder="Your Email *" id="email" required data-validation-required-message="Please enter your email address." />
                                                    <input type="text" class="form-control col-md-4" name="website" placeholder="Your URL *" id="website" required data-validation-required-message="Please enter your web address." />
                                                    <textarea name="comments" class="form-control" id="comments" placeholder="Your Message *" required data-validation-required-message="Please enter a message."></textarea>
                                                    <a class="btn btn-primary pull-right mt30" href="#">Reply</a>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>       
                                <div class="col-xs-2 post-right-col">
                                    <div class="text-right" data-easyshare data-easyshare-url="http://www.distinctivethemes.com/">
                                        <div class="share-button">                                        
                                            <span data-easyshare-total-count>0</span>
                                            <button data-easyshare-button="total">
                                                <span>Total Shares</span>
                                            </button>
                                        </div>

                                        <div class="share-button">
                                            <span data-easyshare-button-count="facebook">0</span>
                                            <button data-easyshare-button="facebook">
                                                <span>Share</span>
                                            </button>                                            
                                        </div>

                                        <div class="share-button">
                                            <span data-easyshare-button-count="twitter">0</span>
                                            <button data-easyshare-button="twitter" data-easyshare-tweet-text="">
                                                <span>Tweet</span>
                                            </button>                                        
                                        </div>

                                        <div class="share-button">                                        
                                            <span data-easyshare-button-count="google">0</span>
                                            <button data-easyshare-button="google">
                                                <span>+1</span>
                                            </button>
                                        </div>

                                        <div data-easyshare-loader>Loading...</div>
                                    </div>
                                </div>                     
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section>
            <div id="mapwrapper"></div>  
        </section>

        <footer class="white-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-6 wow fadeIn" data-wow-delay="0.2s">
                        <span class="copyright">Copyright 2015. Designed by DISTINCTIVE THEMES</span>
                    </div>
                    <div class="col-md-6 text-right">
                        <ul class="list-inline social-links wow fadeIn" data-wow-delay="0.2s">
                            <li>
                                <a href="#"><i class="fa fa-twitter"></i></a>
                            </li>
                            <li>
                                <a href="#"><i class="fa fa-pinterest"></i></a>
                            </li>
                            <li>
                                <a href="#"><i class="fa fa-dribbble"></i></a>
                            </li>
                            <li>
                                <a href="#"><i class="fa fa-facebook"></i></a>
                            </li>
                            <li>
                                <a href="#"><i class="fa fa-behance"></i></a>
                            </li>
                            <li>
                                <a href="#"><i class="fa fa-linkedin"></i></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </footer>

        <div id="bottom-frame"></div>

        <a href="#" id="back-to-top"><i class="fa fa-long-arrow-up"></i></a>

    </div>

    <script src="assets/js/jquery.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/plugins.js"></script>
    <script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script>
    <script src="assets/js/init.js"></script>

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</body>

</html>
