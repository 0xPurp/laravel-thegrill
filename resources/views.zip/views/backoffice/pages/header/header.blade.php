@extends('backoffice.template.template')

@section('back')
    
<h1> Header</h1>   
@endsection