@extends('backoffice.template.template')

@section('back')
    
<h1> About</h1> 


@endsection