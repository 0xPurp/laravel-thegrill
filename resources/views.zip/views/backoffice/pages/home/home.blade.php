@extends('backoffice.template.template')

@section('back')
    
<h1> Home</h1>   
@endsection
